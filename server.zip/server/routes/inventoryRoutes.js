const express = require("express");
const router = express.Router();

const {
  getAllInventory,
  addInventory,
  updateInventory,
  deleteInventory,
} = require("../controllers/inventoryController");

router.get("/", getAllInventory);
router.post("/", addInventory);
router.put("/:id", updateInventory);
router.delete("/:id", deleteInventory);

console.log(router.stack.map(layer => layer.route?.path + " : " + Object.keys(layer.route?.methods || {})));

module.exports = router;